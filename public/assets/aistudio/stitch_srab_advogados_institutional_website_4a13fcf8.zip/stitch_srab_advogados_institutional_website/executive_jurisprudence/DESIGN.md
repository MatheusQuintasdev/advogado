---
name: Executive Jurisprudence
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#45464c'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e73'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839a'
  inverse-primary: '#bfc6df'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#111c2d'
  on-tertiary-container: '#79849a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe2fb'
  primary-fixed-dim: '#bfc6df'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465b'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#d8e3fb'
  tertiary-fixed-dim: '#bcc7de'
  on-tertiary-fixed: '#111c2d'
  on-tertiary-fixed-variant: '#3c475a'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-xl:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 68px
    letterSpacing: -0.02em
  display-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '500'
    lineHeight: 52px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 38px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  body-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 2rem
  gutter-mobile: 1rem
  margin: 4rem
  margin-mobile: 1.25rem
  margin-tablet: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system establishes an authoritative, elite, and discreet visual language suited for premier institutional litigation, cross-border M&A, and high-stakes legal counsel. The aesthetic merges the permanence and legacy of heritage jurisprudence with the surgical precision of modern corporate advisory.

The emotional objective is to project unyielding stability, intellectual gravitas, and institutional prestige. Whitespace is used generously as an expression of confidence and clarity rather than mere absence of content. Visual treatments incorporate refined editorial layouts, hairline metallic accents evoking warm brass and architectural bronze, and frosted surfaces that maintain focus while hinting at structural depth.

## Colors

The palette balances monumental deep tones with luminous, warm metallic counterpoints and pristine structural neutrals.

- **Primary (`#0B1325` - Executive Navy):** Anchors the brand. Used for high-impact typography, primary structural headers, dark-mode surfaces, and dominant branding containers.
- **Secondary (`#C5A059` - Antique Brass / Warm Gold):** Reserved for accentuation, focus rings, fine border hair lines, badges of distinction, and interactive states that demand prestige without ostentation.
- **Tertiary (`#1E293B` - Slate Charcoal):** Governs structural body text, supporting metadata, subdued subheadings, and secondary interactive borders.
- **Neutral (`#F8F9FA` - Marble White):** The primary canvas surface across light interfaces, ensuring absolute legibility and an uncluttered, dignified background.
- **Supporting Gold Tone (`#D4AF37` - Refined Gold):** Applied selectively to interactive hover states, metallic gradient edges, and precise active markers.

## Typography

The typographical pairing relies on the intentional tension between traditional jurisprudence and modern administrative rigor:

- **Playfair Display** serves all editorial and statement levels (`display-*`, `headline-*`). It conveys historical authority, scholarly depth, and executive weight. Display styles employ tight line heights and measured negative letter-spacing for balanced presence.
- **Plus Jakarta Sans** governs functional content (`body-*`, `label-*`). It provides neutral legibility across long-form legal briefs, corporate disclosures, and data tables.
- **Labels & Microcopy:** Rendered with elevated letter spacing and medium-to-bold weights to mimic traditional letterpress engravings and legal document stamps.

## Layout & Spacing

The layout is structured around an asymmetrical 12-column editorial grid engineered to accommodate heavy legal narratives, partner profiles, and statutory disclosures:

- **Grid Architecture:** Desktop views operate on a 12-column framework with generous `2rem` gutters and minimum `4rem` outer canvas padding to preserve an open, catalog-like presentation.
- **Form Factors & Breakpoints:**
  - **Mobile (<768px):** Collapses to a 4-column structure with `1rem` gutters and `1.25rem` margins. Complex tabular data shifts into layered vertical summaries.
  - **Tablet (768px–1024px):** Adopts an 8-column layout with `1.5rem` gutters and `2.5rem` margins.
  - **Desktop (>1024px):** Expands to 12 columns, capped at a maximum container width of `1440px` centered on wide viewports to prevent line-length degradation.
- **Rhythm:** Vertical spacing favors large section divisions (`space-xl` and higher multiples) over tight, utilitarian compression.

## Elevation & Depth

Visual hierarchy uses architectural planes and frosted glassmorphism rather than deep drop shadows:

- **Glassmorphism:** Navigation rails, floating action panels, and modal backdrops utilize translucent substrates (`rgba(11, 19, 37, 0.85)` in dark contexts, or `rgba(248, 249, 250, 0.85)` in light contexts) paired with a `16px` to `24px` backdrop blur.
- **Hairline Foil Outlines:** Surfaces are bounded by 1px translucent brass borders (`rgba(197, 160, 89, 0.25)`), evoking stamped foil stamping on fine stationery.
- **Ambient Shadowing:** Where elevation is necessary (e.g., floating briefing sheets or partner dossiers), shadows are long, soft, and tinted with executive navy (`box-shadow: 0 20px 40px -15px rgba(11, 19, 37, 0.08)`).
- **Z-Index Layering:**
  - `Surface 0`: Canvas background (`#F8F9FA`).
  - `Surface 1`: Resting cards and content segments (White `#FFFFFF` with 1px border).
  - `Surface 2`: Hover states, popovers, and contextual flyouts.
  - `Surface 3`: Modal overlays, formal agreements, and sticky navigation headers.

## Shapes

The design language uses sharp, precise geometric boundaries to communicate exactness and solemnity:

- **Radius Philosophy (`Soft - 1`):** Corner radii are kept minimal (`0.25rem` / `4px` baseline; `0.5rem` / `8px` maximum for larger modals). Elements retain structured, razor-sharp silhouettes that align with corporate legal stationery. Fully rounded or pill-shaped containers are strictly avoided.
- **Dividers & Embellishments:** Structural dividers are rendered as continuous 1px rules in slate (`rgba(30, 41, 59, 0.12)`) or accent brass (`rgba(197, 160, 89, 0.3)`).
- **Aspect Ratios:** Partner portraiture and office architectural photography adhere strictly to formal ratios (3:4 or 4:5 vertical cuts).

## Components

### Buttons
- **Primary:** Solid Executive Navy (`#0B1325`) background with crisp Marble White typography, accented by a subtle gold right-side border or icon indicator. Resting state has no shadow; hover transitions background smoothly to `#1E293B` with a sharp `1px` gold ring expansion (`#C5A059`).
- **Secondary (Brass Hairline):** Transparent background, `1px` solid `#C5A059` border, and text set in `#0B1325`. Hover fills the background with `rgba(197, 160, 89, 0.08)`.
- **Text / Editorial Action:** Monospaced or tracked uppercase label font (`label-md`) with an underline displaced by 4px, accompanied by an elegant brass directional arrow.

### Cards & Case Dossiers
- Rendered on crisp white backings with 1px `#E2E8F0` or `rgba(197, 160, 89, 0.2)` borders.
- Hover reveals a localized top-edge accent border in `#C5A059` (`2px` height) and an ambient navy tint lift. Padding is generous (`space-lg`).

### Input Fields & Selectors
- Background is flat neutral (`#FFFFFF`) with a 1px border in `#CBD5E1`.
- Focused state eliminates generic browser rings in favor of a crisp `1px` border in `#C5A059` and an ultra-subtle outer glow (`0 0 0 1px #C5A059`). Labels hover cleanly above the input in `label-sm` casing.

### Chips & Practice Area Badges
- Non-pill, rectangular tags with `0.25rem` radius. Soft navy or sand background tint (`rgba(11, 19, 37, 0.04)`) with high-contrast slate text and 1px border.
- Active/Selected state swaps to solid Executive Navy with warm brass typography.

### Checkboxes & Radio Buttons
- Crisp square (checkbox) and geometric ring (radio) shapes with thin borders (`1.5px`) in slate.
- Checked state fills with Executive Navy and renders an antique gold checkmark icon.

### Bespoke Elements: Legal Brief Accordion & Attorney Directory
- **Brief Accordions:** Deep navy title triggers, brass chevron indicators that rotate smoothly, and a hairline divider spanning the full column width.
- **Attorney Dossier Grid:** Asymmetric photo-card displays with low-saturation imagery that transitions to rich natural color on hover, accompanied by credentials and admissions set in tracked metadata labels.